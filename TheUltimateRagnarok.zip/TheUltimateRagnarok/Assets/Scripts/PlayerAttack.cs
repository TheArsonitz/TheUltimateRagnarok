﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class PlayerAttack : MonoBehaviour
{
    
    public float damage = 0.0f;
    public KeyCode attacco = KeyCode.F;
    public float tempoRicaricaAttacco = 0.0f;
    protected float isReadyToAttack = 0.0f;

}
